DION HORSE — SITE

Como usar:
1. Extraia este ZIP.
2. Abra index.html no navegador.
3. Para publicar, envie a pasta para um serviço de hospedagem estática.

Observações:
- A identidade visual foi construída com base nos materiais enviados.
- As imagens 1.png, 2.png e 3.png estão na pasta assets.
- Os blocos de equipe estão preparados para receber fotos e nomes reais.
- O e-mail do botão de contato é um placeholder: contato@dionhorse.com.
  Troque pelo e-mail oficial da equipe antes de publicar.
